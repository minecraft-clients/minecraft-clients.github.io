# Mercury
A Minecraft client made by Crystallinqq and Auto.

## Changes compared to the original
- Re-added the Property System that was removed ([minecraft-clients@ad76c42](https://github.com/minecraft-clients/Mercury-Client-BUILDABLE_SRC/commit/ad75c42613d7de8b3c955cb402685abc2f7ba246))

## Credits
[Kix](https://github.com/yandhi) for the Property System
