package fail.mercury.client.client.gui.click.panel.panels;

import fail.mercury.client.client.gui.click.panel.Panel;

/**
 * @author auto on 2/25/2020
 */
public class ConfigPanel extends Panel {

    public ConfigPanel() {
        super("Config");
    }

    @Override
    public void draw(int mouseX, int mouseY, float partialTicks) {
    }
}