package fail.mercury.client.client.events;

import net.b0at.api.event.Event;

public class InsideBlockRenderEvent extends Event {
}
