package fail.mercury.client.client.events;

import net.b0at.api.event.Event;

/**
 * @author auto on 4/6/2020
 */
public class TickEvent extends Event {
}
