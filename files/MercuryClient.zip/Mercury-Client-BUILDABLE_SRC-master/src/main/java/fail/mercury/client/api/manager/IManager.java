package fail.mercury.client.api.manager;

public interface IManager {
    void load();
    void unload();
}
