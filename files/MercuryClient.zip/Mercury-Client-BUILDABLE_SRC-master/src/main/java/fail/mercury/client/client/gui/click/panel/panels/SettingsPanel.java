package fail.mercury.client.client.gui.click.panel.panels;

import fail.mercury.client.client.gui.click.panel.Panel;

/**
 * @author auto on 2/25/2020
 */
public class SettingsPanel extends Panel {

    public SettingsPanel() {
        super("Settings");
    }

    @Override
    public void draw(int mouseX, int mouseY, float partialTicks) {
    }
}