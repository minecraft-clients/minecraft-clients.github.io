package fail.mercury.client.client.gui.click.panel.panels;

import fail.mercury.client.client.gui.click.panel.Panel;

/**
 * @author auto on 2/24/2020
 */
public class FriendsPanel extends Panel {

    public FriendsPanel() {
        super("Friends");
    }

    @Override
    public void draw(int mouseX, int mouseY, float partialTicks) {

    }

}
